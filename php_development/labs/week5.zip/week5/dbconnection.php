<!--
    PHP Web Development with MySQL
    Week 5 Labs - Chapter 15
-->

<?php
    /* dbconnection.php */

    // Database connection constants
    define('DB_HOST', 'localhost');
    define('DB_USER', 'movieguru');
    define('DB_PASSWORD', 'ilikemovies');
    define('DB_NAME', 'Movie');
?>